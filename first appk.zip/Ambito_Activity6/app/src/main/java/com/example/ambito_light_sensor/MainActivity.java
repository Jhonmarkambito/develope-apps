package com.example.ambito_light_sensor;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor lightSensor;
    private TextView infoTextView;
    private View mainLayout;

    private boolean isDarkMode = false;
    private long lastUpdate = 0;
    private static final int DEBOUNCE_DELAY = 500; // 500ms delay
    private static final float LUX_THRESHOLD = 200.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.main_layout);
        infoTextView = findViewById(R.id.infoTextView);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        if (lightSensor == null) {
            infoTextView.setText("Light sensor not available");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (lightSensor != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            float luxValue = event.values[0];
            long currentTime = System.currentTimeMillis();

            // Debounce logic
            if ((currentTime - lastUpdate) > DEBOUNCE_DELAY) {
                lastUpdate = currentTime;
                updateUI(luxValue);
            }
        }
    }

    private void updateUI(float luxValue) {
        // Determine mode based on threshold
        boolean shouldBeDarkMode = luxValue < LUX_THRESHOLD;

        // Update UI only when mode changes or for the first time
        if (shouldBeDarkMode != isDarkMode || infoTextView.getText().toString().contains("0.00")) {
            isDarkMode = shouldBeDarkMode;
            if (isDarkMode) {
                applyDarkMode();
            } else {
                applyLightMode();
            }
        }

        // Always update the Lux value display, rounded to 2 decimal places
        String displayText = String.format(Locale.getDefault(),
                "Jhon Mark Ambito\nT301\nBSIT-3F\nLux: %.2f", luxValue);
        infoTextView.setText(displayText);
    }

    private void applyLightMode() {
        mainLayout.setBackgroundColor(Color.WHITE);
        infoTextView.setTextColor(Color.BLACK);
    }

    private void applyDarkMode() {
        mainLayout.setBackgroundColor(Color.BLACK);
        infoTextView.setTextColor(Color.WHITE);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this application
    }
}
